# 370 Project

#Digi-Lib

**Group:** Always Hungry

**Members:**
- Kartha
- Shrawan
- Raff
- Talha
- Showvik

**Installation Process:**

**Setting up XAMPP:**
- Download XAMPP from here: https://www.apachefriends.org/index.html 
- After downloading, open the app.
- Click Next
- From select components, make sure everything is checked in (everything should be checked by default)
- Click next
- Select the folder you want to install xampp in
- Then click next 4x without modifying any options
- After the installation is finished, Open xampp control panel
- Start Apache and MySQL from the control panel
- This should give you access to the localhost server

**Cloning the project from Gitlab:**
- Go to the gitlab link: https://git.cs.usask.ca/always-hungry/370-project_group_11 
- Open your IDE and clone the project inside the htdoc folder where the xampp was installed in
- After that you should be able to run the website with localhost server
- Go to http://localhost/370-project_group_11

**How to access the database:**
- Go to https://remotemysql.com/phpmyadmin/index.php?db=7nG1YbRy8s
- Username and Password info: username: 7nG1YbRy8s password: 4EDhlkzSFh
- Login with above and this should give you access to the database of the website



